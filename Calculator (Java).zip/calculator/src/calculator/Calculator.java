package calculator;

import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

public class Calculator implements ActionListener {

    JFrame Frame;
    JTextField t;
    JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, bClearAll, bCompute, bDelete, bSetB, bSetA, bDecimal, bPosNeg;
    JRadioButton bMultiply, bAdd, bSubtract, bDivide;
    JLabel lblA, lblB;
    double a = 0, b = 0, result = 0;
    int operator = 0;
  

    Calculator() {
        Frame = new JFrame("Calculator Application");
        t = new JTextField();
        b1 = new JButton("1");
        b2 = new JButton("2");
        b3 = new JButton("3");
        b4 = new JButton("4");
        b5 = new JButton("5");
        b6 = new JButton("6");
        b7 = new JButton("7");
        b8 = new JButton("8");
        b9 = new JButton("9");
        b0 = new JButton("0");
        bDecimal = new JButton(".");
        bClearAll = new JButton("Clear All");
        bAdd = new JRadioButton("Add");
       bMultiply = new JRadioButton("Multiply");
       bSubtract = new JRadioButton("Subtract");
       bDivide = new JRadioButton("Divide");
       bCompute = new JButton("Compute");
       bDelete = new JButton("Delete");
        bSetB = new JButton("Set B");
        bSetA = new JButton("Set A");
        lblA = new JLabel("A: 0");
        lblB = new JLabel("B: 0");
        bPosNeg = new JButton("+/-");


        t.setBounds(26, 21, 297, 42);
        b7.setBounds(54, 265, 50, 40);
        b8.setBounds(159, 265, 50, 40);
        b9.setBounds(260, 265, 50, 40);

        b4.setBounds(54, 317, 50, 40);
        b5.setBounds(159, 317, 50, 40);
        b6.setBounds(260, 317, 50, 40);

        b1.setBounds(54, 369, 50, 40);
        b2.setBounds(159, 369, 50, 40);
        b3.setBounds(260, 369, 50, 40);

        bDecimal.setBounds(260, 432, 50, 40);
        b0.setBounds(159, 432, 50, 40);
        bClearAll.setBounds(180, 219, 130, 34);
        Frame.getContentPane().add(t);
        Frame.getContentPane().add(b7);
        Frame.getContentPane().add(b8);
        Frame.getContentPane().add(b9);
        Frame.getContentPane().add(b4);
        Frame.getContentPane().add(b5);
        Frame.getContentPane().add(b6);
        Frame.getContentPane().add(b1);
        Frame.getContentPane().add(b2);
        Frame.getContentPane().add(b3);
        Frame.getContentPane().add(bDecimal);
        Frame.getContentPane().add(b0);
        Frame.getContentPane().add(bClearAll);

        Frame.getContentPane().setLayout(null);
        
        bAdd.setBounds(40, 75, 141, 23);
        Frame.getContentPane().add(bAdd);
        
        bMultiply.setBounds(180, 75, 141, 23);
        Frame.getContentPane().add(bMultiply);
        
        bSubtract.setBounds(40, 110, 141, 23);
        Frame.getContentPane().add(bSubtract);
        
        bDivide.setBounds(180, 110, 141, 23);
        Frame.getContentPane().add(bDivide);
        
        bCompute.setBounds(26, 219, 141, 34);
        Frame.getContentPane().add(bCompute);
        
        bSetB.setBounds(6, 161, 85, 29);
        Frame.getContentPane().add(bSetB);
        
        bSetA.setBounds(6, 141, 85, 23);
        Frame.getContentPane().add(bSetA);
        
        bDelete.setBounds(180, 185, 130, 34);
        Frame.setVisible(true);
        Frame.setSize(350, 500);
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Frame.setResizable(false);
        Frame.getContentPane().add(t);
        Frame.getContentPane().add(b7);
        Frame.getContentPane().add(b8);
        Frame.getContentPane().add(b9);
        Frame.getContentPane().add(bDivide);
        Frame.getContentPane().add(b4);
        Frame.getContentPane().add(b5);
        Frame.getContentPane().add(b6);
        Frame.getContentPane().add(bMultiply);
        Frame.getContentPane().add(b1);
        Frame.getContentPane().add(b2);
        Frame.getContentPane().add(b3);
        Frame.getContentPane().add(bSubtract);
        Frame.getContentPane().add(bDecimal);
        Frame.getContentPane().add(b0);
        Frame.getContentPane().add(bCompute);
        Frame.getContentPane().add(bAdd);
        Frame.getContentPane().add(bDelete);
        Frame.getContentPane().add(bClearAll);
        Frame.getContentPane().add(bSetA);
        Frame.getContentPane().add(bSetB);
        
        
        
        lblA.setBounds(94, 143, 87, 16);
        Frame.getContentPane().add(lblA);
        
        lblB.setBounds(94, 166, 87, 16);
        Frame.getContentPane().add(lblB);
        
        bPosNeg = new JButton("+/-");
        bPosNeg.setBounds(54, 432, 50, 40);
        Frame.getContentPane().add(bPosNeg);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        b8.addActionListener(this);
        b9.addActionListener(this);
        b0.addActionListener(this);
        bAdd.addActionListener(this);
        bDivide.addActionListener(this);
        bMultiply.addActionListener(this);
        bSubtract.addActionListener(this);
        bDecimal.addActionListener(this);
        bCompute.addActionListener(this);
        bDelete.addActionListener(this);
        bClearAll.addActionListener(this);
        bSetA.addActionListener(this);
        bSetB.addActionListener(this);
        bPosNeg.addActionListener(this);
  
    }

    public void actionPerformed(ActionEvent e) {

    	if (e.getSource() == bSetA) {
            lblA.setText(t.getText());   
            t.setText("");

    	}
    	if (e.getSource() == bSetB) {
            lblB.setText(t.getText());   
            t.setText("");
    	}
    	
        if (e.getSource() == b1) {
            t.setText(t.getText().concat("1"));   
        
        }

        if (e.getSource() == b2) {
            t.setText(t.getText().concat("2"));
        }

        if (e.getSource() == b3) {
            t.setText(t.getText().concat("3"));
        }

        if (e.getSource() == b4) {
            t.setText(t.getText().concat("4"));
        }

        if (e.getSource() == b5) {
            t.setText(t.getText().concat("5"));
        }

        if (e.getSource() == b6) {
            t.setText(t.getText().concat("6"));
        }

        if (e.getSource() == b7) {
            t.setText(t.getText().concat("7"));
        }

        if (e.getSource() == b8) {
            t.setText(t.getText().concat("8"));
        }

        if (e.getSource() == b9){
        t.setText(t.getText().concat("9"));
        
         }
        
        if (e.getSource() == b0){
        t.setText(t.getText().concat("0"));
        
         }
        
        if (e.getSource() == bPosNeg) {
        	t.setText(t.getText().concat("-"));
        }
        
        if (e.getSource() == bDecimal){
        t.setText(t.getText().concat("."));
        
         }
        
        if (e.getSource() == bClearAll) {
            t.setText("");
        }
  
     if(bAdd.isSelected()){		
    	 bSubtract.setSelected(false);
    	 bMultiply.setSelected(false);
    	 bDivide.setSelected(false);
			try { a = Double.parseDouble(lblA.getText()); 
				b = Double.parseDouble(lblB.getText()); 
			} catch (NumberFormatException e1) {a=0; b=0;}
			operator = 1;
			t.setText("");		
    }
        
     if(bSubtract.isSelected()){	
    	 bAdd.setSelected(false);
    	 bMultiply.setSelected(false);
    	 bDivide.setSelected(false);
			try { a = Double.parseDouble(lblA.getText()); 
				b = Double.parseDouble(lblB.getText()); 
			} catch (NumberFormatException e2) {a=0; b=0;}
			operator = 2;
			t.setText("");
            }
     if(bMultiply.isSelected()){
    	 bSubtract.setSelected(false);
    	 bAdd.setSelected(false);
    	 bDivide.setSelected(false);
			try { a = Double.parseDouble(lblA.getText()); 
				b = Double.parseDouble(lblB.getText()); 
			} catch (NumberFormatException e3) {a=0; b=0;}
			operator = 3;
			t.setText("");
            }
     if(bDivide.isSelected()){	
    	 bSubtract.setSelected(false);
    	 bMultiply.setSelected(false);
    	 bAdd.setSelected(false);
			try { a = Double.parseDouble(lblA.getText()); 
				b = Double.parseDouble(lblB.getText()); 
			} catch (NumberFormatException e4) {a=0; b=0;}
			operator = 4;
			t.setText("");
            }
           
        
    
    if (e.getSource() == bCompute) {
        switch (operator) {
            case 1:
                result = a + b;
                break;
            case 2:
                result = a - b;
                break;
            case 3:
                result = a * b;
                break;
            case 4:
                result = a / b;
                break;

            default:
                result = 0;
        }
        t.setText("" + result);
        lblA.setText("");
		lblB.setText("");
    }
    if (e.getSource() == bClearAll) {
        t.setText("");
    }
    if (e.getSource() == bDelete) {
        String s = t.getText();
        t.setText("");
        for (int i = 0; i < s.length() - 1; i++) {
            t.setText(t.getText() + s.charAt(i));

        
        }
        }  
}


    public static void main(String[] args) {

        new Calculator();

    }
}
